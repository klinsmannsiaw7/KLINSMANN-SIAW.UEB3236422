<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "study_planner";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$success_message = "";
if (isset($_GET['status']) && $_GET['status'] == 'success') {
    $success_message = "Task added successfully!";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Study Planner</title>
   <style>
body {
  font-family: sans-serif;
  background-color: #121212; /* Dark background */
  color: #fff;
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  margin: 0;
}

.container {
  background-color: #222; /* Dark container background */
  border-radius: 15px;
  padding: 30px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.5);
  width: 400px;
}

h1 {
  text-align: center;
  color: #9400D3; /* Purple heading */
  margin-bottom: 20px;
  font-size: 2em;
}

label {
  display: block;
  margin-bottom: 5px;
  color: #ccc;
}

input[type="text"],
textarea {
  width: 100%;
  padding: 10px;
  margin-bottom: 15px;
  border: 1px solid #444;
  border-radius: 5px;
  background-color: #333;
  color: #fff;
  box-sizing: border-box;
}

textarea {
  height: 80px;
  resize: vertical;
}

button {
  background-color: #9400D3; /* Purple button */
  color: #fff;
  padding: 12px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  width: 100%;
  font-size: 1.1em;
  transition: background-color 0.3s ease;
}

button:hover {
  background-color: #702963; /* Darker purple on hover */
}

input[type="date"] {
  width: 100%;
  padding: 10px;
  margin-bottom: 15px;
  border: 1px solid #444;
  border-radius: 5px;
  background-color: #333;
  color: #fff;
  box-sizing: border-box;
}
</style>
</head>
<body>
    <div class="container">
        <h1>Student Study Planner</h1>
        
        <form action="process.php" method="POST">
            <div class="form-group">
                <label for="subject">Subject</label>
                <input type="text" id="subject" name="subject" placeholder="e.g. Mathematics" required>
            </div>
            
            <div class="form-group">
                <label for="task">Task</label>
                <textarea id="task" name="task" placeholder="Describe the study task..." required></textarea>
            </div>
            
            <div class="form-group">
                <label for="due_date">Due Date</label>
                <input type="date" id="due_date" name="due_date" required>
                <div class="date-hint">Format: mm/dd/yyyy</div>
            </div>
            
            <button type="submit" name="submit">Add To Planner</button>
        </form>
        
        <?php if (!empty($success_message)): ?>
            <div class="success-message"><?php echo $success_message; ?></div>
        <?php endif; ?>
    </div>
</body>
</html>